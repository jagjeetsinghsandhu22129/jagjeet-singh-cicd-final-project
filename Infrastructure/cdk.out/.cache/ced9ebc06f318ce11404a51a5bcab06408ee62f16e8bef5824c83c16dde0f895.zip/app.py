# backend/app.py

def handler(event, context):
    return {
        'statusCode': 200,


        'body': 'This is my Lambda Functio!!!!!!!!!!!'
    }
